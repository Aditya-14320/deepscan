from bs4 import BeautifulSoup
import re

# Load local HTML file (fake dark web page)
def load_fake_html(path):
    with open(path, 'r', encoding='utf-8') as file:
        return file.read()

# Leak detection using regex
def detect_leaks(text):
    leaks = []

    # Detect email addresses
    emails = re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", text)
    if emails:
        leaks.append(("Emails", emails))

    # Detect passwords (simple pattern: words after 'Password:')
    passwords = re.findall(r"[Pp]assword[:\s]+(\S+)", text)
    if passwords:
        leaks.append(("Passwords", passwords))

    # Detect credit card numbers (16 digits in groups)
    cards = re.findall(r"\b(?:\d[ -]*?){13,16}\b", text)
    if cards:
        leaks.append(("Credit Cards", cards))

    return leaks

# Main function
def run_deep_scan():
    html = load_fake_html("test_darkweb_page.html")
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text()

    leaks = detect_leaks(text)

    if not leaks:
        print("✅ No leaks found.")
    else:
        print("🚨 Potential Data Leaks Detected:\n")
        for leak_type, items in leaks:
            print(f"🔹 {leak_type}:")
            for item in items:
                print(f"   ➤ {item}")
        print("\n🟠 Risk Level: HIGH")

# Run the demo
if __name__ == "__main__":
    run_deep_scan()
